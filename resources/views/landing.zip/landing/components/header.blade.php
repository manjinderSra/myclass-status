<header id="header" class="header d-flex align-items-center sticky-top">
  <div class="container-fluid container-xl position-relative d-flex align-items-center">

    <a href="{{route('landing.index')}}" class="logo d-flex align-items-center me-auto">
      <img src="{{ asset('landing/img/Group (2).png') }}" alt="logo" height="50px">
    </a>

    <nav id="navmenu" class="navmenu">
      <ul>
        <li><a href="/" class="{{ request()->is('/') ? 'active' : '' }}">Home</a></li>
        <li><a href="{{route('landing.about')}}" class="{{ request()->routeIs('landing.about') ? 'active' : '' }}">About Us</a></li>
        <li><a href="{{route('landing.pricing')}}" class="{{ request()->routeIs('landing.pricing') ? 'active' : '' }}">Pricing</a></li>
        <li><a href="{{route('landing.contact')}}" class="{{ request()->routeIs('landing.contact') ? 'active' : '' }}">Contact Us</a></li>
      </ul>
      <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
    </nav>

    <div class="d-flex gap-2 m-3">
      @auth
        @if(auth()->user()->role === 'school')
          <a href="{{ route('school.dashboard') }}" class=" btn-getstarted">School Dashboard</a>
          <form action="{{ route('school.logout') }}" method="POST" class="d-inline">
            @csrf
            <button type="submit" class="btn-auth logout">Logout</button>
          </form>
        @elseif(auth()->user()->role === 'saasAdmin')
          <a href="{{ route('saasAdmin.dashboard') }}" class=" btn-getstarted">Admin Dashboard</a>
        @else
          <a href="{{ route('school.login') }}" class=" btn-getstarted">Login</a>
          {{-- <a href="{{ route('school.signup') }}" class="btn-auth signup">Sign Up</a> --}}
        @endif
      @else
        <a href="{{ route('school.login') }}" class=" btn-getstarted ">Login</a>
        {{-- <a href="{{ route('school.signup') }}" class="btn-auth signup">Sign Up</a> --}}
      @endauth
      {{-- <a class="btn-getstarted" href="{{route('landing.contact')}}">Connect With Us</a> --}}
    </div>
  </div>
</header> 